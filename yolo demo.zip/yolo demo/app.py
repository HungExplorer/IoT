from flask import Flask, render_template, request, jsonify, redirect, url_for
import cv2, numpy as np, base64, io
from PIL import Image
from ultralytics import YOLO

app = Flask(__name__)
model = YOLO('my_model.pt')
labels = model.names
CONF_THRESH = 0.5

# Store past detections in memory (or replace with DB)
detections_store = []  # each: {'image': <dataURL>, 'counts': {...}, 'best': (label, score)}


def decode_base64_img(data_url: str) -> np.ndarray:
    header, encoded = data_url.split(',', 1)
    img = Image.open(io.BytesIO(base64.b64decode(encoded))).convert('RGB')
    return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)


def encode_img_to_base64(img_cv: np.ndarray) -> str:
    _, buf = cv2.imencode('.jpg', img_cv)
    return 'data:image/jpeg;base64,' + base64.b64encode(buf).decode()


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/detect', methods=['POST'])
def detect():
    data = request.json
    frame = decode_base64_img(data['image'])
    res = model(frame, verbose=False)[0]

    counts = {}
    best = (None, 0.0)
    # draw boxes
    for box in res.boxes:
        conf = float(box.conf)
        if conf < CONF_THRESH: continue
        cls = int(box.cls)
        lbl = labels[cls]
        counts[lbl] = counts.get(lbl, 0) + 1
        if conf > best[1]: best = (lbl, conf)
        x1,y1,x2,y2 = map(int, box.xyxy.cpu().numpy().flatten())
        cv2.rectangle(frame, (x1,y1),(x2,y2),(0,255,0),2)
        cv2.putText(frame, f"{lbl} {conf:.2f}", (x1,y1-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

    img_out = encode_img_to_base64(frame)
    # Save for gallery
    detections_store.insert(0, {
        'image': img_out,
        'counts': counts,
        'best': best
    })
    return jsonify({ 'image': img_out, 'counts': counts, 'best': best })


@app.route('/gallery')
def gallery():
    return render_template('gallery.html', items=detections_store)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)