const video = document.getElementById('video');
const overlay = document.getElementById('overlay');
const ctx = overlay.getContext('2d');
const btn = document.getElementById('actionBtn');

// Start camera
navigator.mediaDevices.getUserMedia({video:{facingMode:{exact:'environment'}}})
  .catch(()=>navigator.mediaDevices.getUserMedia({video:true}))
  .then(s=>video.srcObject=s)
  .catch(e=>alert('No camera: '+e));

btn.addEventListener('click', async ()=>{
  // capture frame
  const c = document.createElement('canvas');
  c.width = video.videoWidth; c.height = video.videoHeight;
  c.getContext('2d').drawImage(video,0,0);
  const dataUrl = c.toDataURL('image/jpeg');

  // send
  const res = await fetch('/detect',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({image:dataUrl})
  });
  const j = await res.json();

  // draw result
  const img = new Image(); img.onload = ()=>{
    overlay.width=img.width;overlay.height=img.height;
    ctx.drawImage(img,0,0);
  };
  img.src = j.image;
  // redirect after small delay
  setTimeout(()=>location.href = '/gallery', 800);
});