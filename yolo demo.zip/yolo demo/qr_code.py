import qrcode
url = " https://c3d8-42-113-114-116.ngrok-free.app"
img = qrcode.make(url)
img.save("qr_code.png")